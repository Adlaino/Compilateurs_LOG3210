Le TP était plus long que prévue, alors on n'a pas terminé la partie du fall.
