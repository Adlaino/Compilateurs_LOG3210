import java.util.HashSet;
import java.util.HashMap;
import java.util.Vector;
import java.io.PrintWriter;
import java.io.IOException;

public class PrintExpressionDAGVisitor implements ParserVisitor
{

  String numberPrefix = "nbr"; // Il faut mettre un prefix lorsque le bloc contient des chiffres

  HashMap<String, String> m_updates = new HashMap<String, String>(); // Pour obtenir le noeud le plus récent
  HashMap<String, Integer> m_arcs = new HashMap<String, Integer>(); // Pour savoir combien de liens (parent) un noeud possède
  Vector<String> m_live = new Vector<String>(); // Pour savoir quelle sont les variables vives a la fin d'un block
  Vector<String> m_tree = new Vector<String>(); // Pour imprimer l'arbre après avoir finis la visite
  Vector<myNode> m_existingNodes = new Vector<myNode>(); // Structure pour savoir les noeud communs

  HashSet<String> m_nodes = new HashSet<String>(); // Structure qui contient les noeuds
  HashSet<String> m_leafs = new HashSet<String>(); // Structure qui contient les feuilles
  HashSet<String> m_links = new HashSet<String>(); // Structure qui contient les liens entre les noeuds et les feuilles

  String m_outputFileName = null;
  PrintWriter m_writer = null;

  public PrintExpressionDAGVisitor(String outputFilename)  {
    m_outputFileName = outputFilename;
  }


  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(SimpleNode node, Object data) {
    return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTProgram node, Object data) {

    try{
      m_writer = new PrintWriter(m_outputFileName, "UTF-8");
    } catch (IOException e) {
      System.out.println("Failed to create ouput file.");
      return null;
    }
    m_writer.println("graph g {");

    // Visite les noeuds pour construire l'arbre et imprimer les noeuds
    node.childrenAccept(this, null);

    // On enlève les feuilles inutiles
    for (String leafOrNode : m_arcs.keySet()) {
      if(!(leafOrNode.matches("^[0-9]+$")) && m_arcs.get(leafOrNode) == 0) {
        for (String aNode : m_tree) {
          if(aNode.contains("  " + leafOrNode)) {
            m_tree.remove(aNode);
            m_leafs.remove(leafOrNode);
            break;
          }
        }
      }
    }

    for (String order : m_arcs.keySet()) {  // On impose l'ordre topologique

      for (String aNode : m_tree) { // On parcours l'arbre pour trouver quelle noeud on doit traitée d'abord
        if(aNode.contains("  " + order)) {

          String label = extractLabel(aNode); // Extraction du label
          if (!m_live.contains(label)) { // Verifier si elle est n'est pas vive
            if (aNode.contains("xlabel=")) { // Noeud
              label = m_updates.get(label); // Convertion pour obtenir le noeud le plus recent
              if (m_arcs.containsKey(label) && m_arcs.get(label) == 0) { // On vérifie si le noeud est une racine
                reduceArcs(label); // On réduit le nombre de liens de ses enfants
                aNode = aNode.substring(0, aNode.length() - 1) + ", fillcolor = red, style = filled]"; // Code mort
                deleteNode(label);
              }
            } else { // Feuille
              if (label.matches("^[0-9]+$")) { // Verifier si la feuille est un chiffre
                label = numberPrefix + label; // Ajout du prefix si oui
              }
              if (m_arcs.containsKey(label) && m_arcs.get(label) == 0) { // Code mort
                aNode = aNode.substring(0, aNode.length() - 1) + ", fontcolor=red]";
              }
            }
          }
          m_writer.println(aNode);
          break; // On sort de la loop for lorsqu'on a trouver le noeud a traiter
        }
      }
    }

    // La visite mémorise les liens que l'on imprime ensuite
    for (String link : m_links) {
      m_writer.println("  " + link);
    }

    m_writer.print("  {rank=sink ");
    for (String leaf : m_leafs) {
      m_writer.print(leaf + " ");
    }
    m_writer.println("}");

    m_writer.println("}");

    m_writer.close();
  	return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTBlock node, Object data) {
  	node.childrenAccept(this, null);
  	return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTLive node, Object data) {
    m_live = node.getLive(); // On récupère les variables vives
  	return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTStmt node, Object data) {
  	node.childrenAccept(this, null);
  	return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTAssignStmt node, Object data) {

    ASTIdentifier assigned = (ASTIdentifier)node.jjtGetChild(0);
    String currentNode = String.valueOf(m_nodes.size());

    String enfantGauche = (String) node.jjtGetChild(1).jjtAccept(this, null);
    if(m_updates.containsKey(enfantGauche)) { // On vérifie si l'enfant a été assignée une autre valeur
      enfantGauche = m_updates.get(enfantGauche);
    }

    String enfantDroite = (String) node.jjtGetChild(2).jjtAccept(this, null);
    if(m_updates.containsKey(enfantDroite)) { // On vérifie si l'enfant a été assignée une autre valeur
      enfantDroite = m_updates.get(enfantDroite);
    }

    myNode tempNode = new myNode(currentNode, node.getOp(),enfantGauche, enfantDroite, assigned.getValue(), node);

    boolean duplicate = false;
    String duplicateValue = "";
    String duplicateID = "";

    for(myNode nNode : m_existingNodes) {
      if(tempNode.equals(nNode)) {  // Vérifier si le noeud qu'on a ajouter possède les mêmes enfants, si oui c'est un code dupliquée
        duplicate = true;
        duplicateID = nNode.value;
        duplicateValue = nNode.id;
        node.setDuplique(true);
      }
    }
    m_existingNodes.add(tempNode);

    if(!duplicate) {
      addNode(String.valueOf(m_nodes.size()), node.getOp(), assigned.getValue());
      addLink(currentNode, enfantGauche);
      addLink(currentNode, enfantDroite);

    } else {
      for(String str : m_tree) { // On parcours l'arbre pour eliminer le code qui est dupliquée
        if(str.contains("  " + duplicateValue)) {
          m_tree.removeElement(str);
          break;
        }
      }
      addNode(duplicateValue, node.getOp(),  duplicateID + "," + assigned.getValue());
    }
    return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTAssignUnaryStmt node, Object data) {
    String currentNode = String.valueOf(m_nodes.size());

    String enfantGauche = (String) node.jjtGetChild(0).jjtAccept(this, null);
    if(m_updates.containsKey(enfantGauche)) { // On vérifie si l'enfant a été assignée une autre valeur
      enfantGauche = m_updates.get(enfantGauche);
    }

    String enfantDroite = (String) node.jjtGetChild(1).jjtAccept(this, "-");
    if(m_updates.containsKey(enfantDroite)) { // On vérifie si l'enfant a été assignée une autre valeur
      enfantDroite = m_updates.get(enfantDroite);
    }

    ASTIdentifier assigned = (ASTIdentifier)node.jjtGetChild(0);

    addNode(String.valueOf(m_nodes.size()), "=", assigned.getValue());
    addLink(currentNode, enfantGauche);
    addLink(currentNode, enfantDroite);

    return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTAssignDirectStmt node, Object data) {

    ASTIdentifier assigned = (ASTIdentifier)node.jjtGetChild(0);
    String currentNode = String.valueOf(m_nodes.size());

    String enfantGauche = (String) node.jjtGetChild(1).jjtAccept(this, null);
    if(m_updates.containsKey(enfantGauche)) { // On vérifie si l'enfant a été assignée une autre valeur
      enfantGauche = m_updates.get(enfantGauche);
    }

    addNode(String.valueOf(m_nodes.size()), "=", assigned.getValue());
    addLink(currentNode, enfantGauche);
    addLink(currentNode, assigned.getValue());
    return null;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTExpr node, Object data) {
    String var = (String) node.jjtGetChild(0).jjtAccept(this, null);
  	return var;
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTIntValue node, Object data) {
    addLeaf(numberPrefix + String.valueOf(node.getValue())); // On ajoute un prefix au chiffre
    return numberPrefix + String.valueOf(node.getValue());
  }

  // Paramètre data: On ne transmet rien aux enfants
  // Valeur de retour: On ne retourne rien aux parents
  public Object visit(ASTIdentifier node, Object data) {

    if(data != null && ((String) data).contains("-")) { // Dans le cas ou data vient d'un unary assignement
      addLeaf("-" + node.getValue());
    } else {
      addLeaf(node.getValue());
    }
    return node.getValue();
  }

  public void addLink(String id1, String id2)
  {
    m_arcs.put(id2, m_arcs.get(id2) + 1); // Ajout des liens, id1 est le parent, id2 est le fils
    m_links.add(id1 + " -- " + id2);
  }

  public void addLeaf(String uniqueLabel) {
    if(m_leafs.contains(uniqueLabel))
      return;
    m_arcs.put(uniqueLabel, 0);
    m_leafs.add(uniqueLabel);

    if(uniqueLabel.contains(numberPrefix)) {
      String labelWithoutPrefix = uniqueLabel.replace(numberPrefix,"");
      m_tree.add("  " + uniqueLabel + " [label=\"" + labelWithoutPrefix + "\", shape=\"none\"]");
    } else {
      m_tree.add("  " + uniqueLabel + " [label=\"" + uniqueLabel + "\", shape=\"none\"]");
    }
  }

  public void addNode(String uniqueId, String label, String notation) {

    if(m_nodes.contains(uniqueId)) {
      m_tree.add("  " + uniqueId + " [label=\"" + label + "\", xlabel=\"" + notation + "\", shape=\"circle\"]");
      return;
    }

    m_updates.put(notation, uniqueId); // On met a jour la valeur du noeud
    m_arcs.put(uniqueId, 0); //On met a jour la valeur de l'arc du noeud
    m_tree.add("  " + uniqueId + " [label=\"" + label + "\", xlabel=\"" + notation + "\", shape=\"circle\"]");
    m_nodes.add(uniqueId); // On l'ajoute dans la liste de noeud

  }
  public void reduceArcs(String parent) {
      for(String link : m_links) {
        String parentNode = link.split("--")[0].trim(); // On cherche le noeud parent
        if(parent.equals(parentNode)) {
          String child = link.split("--")[1].trim(); // On cherche les enfants et on reduit le nombre d'arc par 1
          m_arcs.put(child, m_arcs.get(child) - 1);
        }
      }
  }
  public String extractLabel(String node) {
    String label = "";
    if(node.contains("xlabel=")) { // Noeud
      int indexStart = node.indexOf("xlabel=\"");
      indexStart += 8; // Nombre de caractères dans xlabel=\"
      int indexEnd = node.indexOf("\"", indexStart);
      label = node.substring(indexStart, indexEnd);
      if(label.contains(",")) {
        label = label.split(",")[0];
      }
    }
    else { // Feuille
      int indexStart = node.indexOf("label=\"");
      indexStart += 7; // Nombre de caractères dans label=\"
      int indexEnd = node.indexOf("\"",indexStart);
      label = node.substring(indexStart, indexEnd);
    }
    return label;
  }
  private static class myNode { // Structure noeud
    public String id; // L'identifiant du noeud
    public String op; // L'opérateur du noeud
    public String left; // Enfant gauche
    public String right; // Enfant droite
    public String value; // La valeur du noeud
    public SimpleNode node; // Noeud de l'arbre

    public myNode (String id, String op, String left, String right, String value, SimpleNode node) {
      this.id = id;
      this.op = op;
      this.left = left;
      this.right = right;
      this.value = value;
      this.node = node;
    }

    public String toString() {
      return "id: " + id + " op: " + op + " left " + left + " right " + right;
    }

    public boolean equals(myNode mNode) {
      return (this.op.equals(mNode.op) && this.left.equals(mNode.left) && this.right.equals(mNode.right));
    }

  }

  public void deleteNode(String uniqueID) { // Assigne un noeud mort pour le visiteur de code optimisé
    for(myNode node : m_existingNodes) { // On cherche le noeud
      if(node.id.equals(uniqueID)){
        if(node.node.toString() == "AssignStmt") {
          ((ASTAssignStmt)node.node).setMort(true); // On assigne le boolean  qui indique si le noeud est mort
        } else if (node.node.toString() == "AssignDirectStmt") {
          ((ASTAssignDirectStmt)node.node).setMort(true);
        }
        return;
      }
    }
  }
}
