public class CodeGenVisitor implements ParserVisitor
{
	int label = 0;
	int tempVariables = 0;
	String labelIdentifier = "^(L[0-9]+)$";

	public Object visit(SimpleNode node, Object data) {
		return data;
	}

	public Object visit(ASTProgram node, Object data) {
		data = node.jjtGetChild(0).jjtAccept(this, data);
		return data;
	}

	public Object visit(ASTBlock node, Object data) {
		String nextBlock = "";
        // Store information of block before entering a new block
		if(	node.jjtGetParent().toString().compareTo("WhileStmt") == 0
			|| (node.jjtGetParent().toString().compareTo("IfStmt") == 0
			&& data != null
			&& data.toString().matches(labelIdentifier))) {

			nextBlock = data.toString();
			data = "";
		}
        // Traverse all child nodes
		for(int i = 0; i < node.jjtGetNumChildren(); i++) {
            data = node.jjtGetChild(i).jjtAccept(this, data);
		}
        // Last statement of a block
		if(!(nextBlock.isEmpty())){
			System.out.println("goto " + nextBlock);
		}
		return data;
	}

	public Object visit(ASTStmt node, Object data) {
        data = node.jjtGetChild(0).jjtAccept(this, data);
		return data;
	}

	public Object visit(ASTAssignStmt node, Object data) {
        String rightSide = "";
        // Prints label before printing assignment statement
        if( data != null && data.toString().matches(labelIdentifier) ){
            System.out.println(data.toString() + ": ");
            data = "";
        }
        // Obtain de last node
        data = node.jjtGetChild(node.jjtGetNumChildren() - 1).jjtAccept(this, data);

        rightSide = data.toString();
        // Traverse the tree in reverse, starting from the end
		for(int i = node.jjtGetNumChildren() - 2; i >= 0; i--) {

			data = node.jjtGetChild(i).jjtAccept(this, data);
            // Regular '=' operator
			if(((String)node.getOps().get(i)).equals("="))  {
				System.out.println(data.toString() + " = " + rightSide);
			}
            // Create temp variables if it's not a regular '=' operator
			else {
				String operator = ((String)node.getOps().get(i)).replace('=',' ');
				String tempVariable = "t" + Integer.toString(tempVariables ++);
				System.out.println(tempVariable + " = " + data.toString());
				System.out.println(data.toString() + " = " + tempVariable + operator + rightSide);
			}
			rightSide = data.toString();
		}
		return data;
	}

	public Object visit(ASTIfStmt node, Object data) {
        if(node.jjtGetNumChildren() == 2) {
            String ifThen = "L" + label++;
            String nextBlock = "L" + label++;
            // Prints label
            if(data != null && data.toString().matches(labelIdentifier)) {
                System.out.println(data.toString() + ": ");
                data = "";
            }
            node.jjtGetChild(0).jjtAccept(this, data);

            System.out.println(ifThen + ": ");
            data = nextBlock;

            data = node.jjtGetChild(1).jjtAccept(this, data);
            System.out.println(nextBlock + ": ");
            data = nextBlock;
            return data;
        }

        // Presence of an else block

		else{
            String ifThen = "L" + label ++;
            String ifElse = "L" + label ++;
            // Prints label
            if(data != null && data.toString().matches(labelIdentifier)){
                System.out.println(data.toString() + ": ");
                data = "";
            }

            node.jjtGetChild(0).jjtAccept(this, data);

            String nextBlock = "L" + label ++;

            System.out.println(ifThen + ": ");
            data = nextBlock;
            data = node.jjtGetChild(1).jjtAccept(this, data);

            System.out.println(ifElse + ": ");
            data = nextBlock;
            data = node.jjtGetChild(2).jjtAccept(this, data);

            System.out.println(nextBlock + ": ");
            data = nextBlock;
            return data;
		}
	}


	public Object visit(ASTWhileStmt node, Object data) {
		String wLabel = "";
        // Prints label
		if(data != null && data.toString().matches(labelIdentifier)){
			wLabel = data.toString();
			data = "";
		}
		else{
		    // Nothing before the while block
			wLabel = "L" + label++;
		}
		String nextBlock = "L" + label++;

		String ifThen = "L" + label++;
		node.jjtGetChild(0).jjtAccept(this, data);
		System.out.println(ifThen + ": ");
		data = wLabel;

        data = node.jjtGetChild(1).jjtAccept(this, data);
		System.out.println(nextBlock + ": ");
		data = nextBlock;
		return data;
	}

	public Object visit(ASTCompExpr node, Object data) {
		int compTrue = label - 2;
		int compFalse = label - 1;
		String compExpression = "";

        if(node.jjtGetParent().toString().compareTo("WhileStmt") == 0){
            compTrue++;
            compFalse--;
        }

        data = node.jjtGetChild(0).jjtAccept(this, data);

		if(data.toString().contains("||")){
			data = data.toString().split("\\|\\|")[1];
		}
		else if(data.toString().contains("&&")){
			data = data.toString().split("\\&\\&")[1];
		}

		compExpression += data.toString();
		for(int i = 1; i < node.jjtGetNumChildren(); i++) {
			compExpression += node.getOps().get(i-1);
			data = node.jjtGetChild(i).jjtAccept(this, data);


			if(data.toString().contains("&&")){
			    // Goes to the next label
                compExpression += data.toString().split("\\&\\&")[0];
                System.out.println("if " + compExpression + " goto L" + ++label); // If true
                System.out.println("goto L" + compFalse); // If false

                compExpression = data.toString().split("\\&\\&")[1];
                System.out.print("L" + label++ + ": ");
			}
			else if(data.toString().contains("||")){
                compExpression += data.toString().split("\\|\\|")[0];
                System.out.println("if " + compExpression + "goto L" + compTrue);// If true
                System.out.println("goto L" + ++label);// If false

                compExpression = data.toString().split("\\|\\|")[1];
                System.out.print("L" + label++ + ": ");
			}
			else {
				compExpression += data.toString();
				System.out.println("if " + compExpression + " goto L" + compTrue); // If true
				System.out.println("goto L" + compFalse);// If false
			}
		}
		return data;
	}

	public Object visit(ASTAndOrExpr node, Object data) {
		data =  node.jjtGetChild(0).jjtAccept(this, data);
        String pattern = "^(L[0-9]+:)";

		if(data != null && data.toString().contains(pattern)){
			System.out.print(data.toString().split(pattern)[0]);
			data = data.toString().split(pattern)[1].trim();
		}

		for(int i = 1; i < node.jjtGetNumChildren(); i++) {
		    String temp = data.toString() + node.getOps().get(i-1).toString();
			data = temp + node.jjtGetChild(i).jjtAccept(this, data).toString();
		}
		return data;
	}

	public Object visit(ASTNotExpr node, Object data) {
		int nbNot = node.getOps().size();
		data = node.jjtGetChild(0).jjtAccept(this, data);
		if(nbNot % 2 == 1) {
			String tempVariable = "t" + Integer.toString(tempVariables ++);
			System.out.println(tempVariable + " = not" + data.toString());
			data = tempVariable;
		}
		return data;
	}

	public Object visit(ASTAddExpr node, Object data) {
	    // Continue down the tree
		data = node.jjtGetChild(0).jjtAccept(this, data);

			for(int i = 1; i < node.jjtGetNumChildren(); i++) {
			    // Create tempVariable
				String tempVariable = "t" + Integer.toString(tempVariables ++);
				String rightSide = "";
                // Obtain the operator
                String operator = node.getOps().get(i-1).toString() ;
                // Climb down tree to obtain right hand side of the operator
				rightSide = node.jjtGetChild(i).jjtAccept(this, rightSide).toString();
				System.out.println(tempVariable + " = " + data.toString() + operator + rightSide.toString());
				data = tempVariable;
			}
			return data;
	}


	public Object visit(ASTMultExpr node, Object data) {
        // Continue down the tree
        data = node.jjtGetChild(0).jjtAccept(this, data);

        for(int i = 1; i < node.jjtGetNumChildren(); i++) {
            // Create tempVariable
            String tempVariable = "t" + Integer.toString(tempVariables ++);
            String rightSide = "";
            // Obtain the operator
            String operator = node.getOps().get(i-1).toString() ;
            // Climb down tree to obtain right hand side of the operator
            rightSide = node.jjtGetChild(i).jjtAccept(this, rightSide).toString();
            System.out.println(tempVariable + " = " + data.toString() + operator + rightSide.toString());
            data = tempVariable;
        }
        return data;
	}

	public Object visit(ASTPowExpr node, Object data) {
        // Continue down the tree
        data = node.jjtGetChild(0).jjtAccept(this, data);

        for(int i = 1; i < node.jjtGetNumChildren(); i++) {
            // Create tempVariable
            String tempVariable = "t" + Integer.toString(tempVariables ++);
            String rightSide = "";
            // Obtain the operator
            String operator = node.getOps().get(i-1).toString() ;
            // Climb down tree to obtain right hand side of the operator
            rightSide = node.jjtGetChild(i).jjtAccept(this, rightSide).toString();
            System.out.println(tempVariable + " = " + data.toString() + operator + rightSide.toString());
            data = tempVariable;
        }
        return data;
	}

	public Object visit(ASTNegExpr node, Object data) {
		int negExpressions = node.getOps().size();
		data = node.jjtGetChild(0).jjtAccept(this, data);
		// If it's not pair 
		if(negExpressions % 2 == 1){
		    // Check if it's not a digit, create a tampon variable if so
			if(!(data.toString().matches("^[1-9]+$"))) {
				String tempVariable = "t" + Integer.toString(tempVariables ++);
				System.out.println(tempVariable + " = -" + data.toString());
				data = tempVariable;
			}
			else {
			    // Just a digit, negate it
				data = "-" + data.toString();
			}
		}
		return data;
	}

	public Object visit(ASTBasicExpr node, Object data) {
		data = node.jjtGetChild(0).jjtAccept(this, data);
		return data;
	}

	public Object visit(ASTRealValue node, Object data) {
		data = node.getValue();
		return data;
	}

	public Object visit(ASTIntValue node, Object data) {
		data = node.getValue();
		return data;
	}

	public Object visit(ASTIdentifier node, Object data) {
		data = node.getValue();
		return data;
	}
}