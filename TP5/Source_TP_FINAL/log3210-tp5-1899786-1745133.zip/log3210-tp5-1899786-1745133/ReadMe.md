Le coloriage fonctionne très bien selon nos tests, mais des fois le spill ne fonctionne pas à 100%.
